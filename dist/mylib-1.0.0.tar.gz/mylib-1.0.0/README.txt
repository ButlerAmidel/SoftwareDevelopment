python -m unittest discover -s myLib/tests -p "test*.py"
